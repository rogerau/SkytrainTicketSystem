
public class Test {

	public static void main(String[] args) {
		MyNumber obj1 = new MyNumber();
		System.out.print(obj1.digitAt(3));
	}

}
